import React from 'react'

const Registration = () => {
    return (
        <div>
            <h1>Registration</h1>
        </div>
    )
}

export default Registration